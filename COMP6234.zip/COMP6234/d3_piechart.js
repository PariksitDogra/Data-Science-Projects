var pie = new d3pie("pieChart", {
	"header": {
		"title": {
			"text": "Hours Watched (Q3 2019)",
			"fontSize": 26,
			"font": "times new roman"
		},
		"subtitle": {
			"text": "A pie chart showing the amount of hours watched on each platform",
			"color": "#999999",
			"fontSize": 13,
			"font": "times new roman"
		},
		"titleSubtitlePadding": 13
	},
	"footer": {
		"color": "#999999",
		"fontSize": 10,
		"font": "open sans",
		"location": "bottom-left"
	},
	"size": {
		"canvasWidth": 590,
		"pieInnerRadius": "60%",
		"pieOuterRadius": "87%"
	},
	tooltips: {
		enabled: true,
		type: "caption"
	 },
	"data": {
		"sortOrder": "value-desc",
		"content": [
			{
				"label": "Youtube Gaming",
				"value": 595306362,
				"color": "#e41d1d",
				"caption": "Hours Watched: 595,306,362"
			},
			{
				"label": "Facebook Gaming",
				"value": 124103064,
				"color": "#086780",
				"caption": "Hours Watched: 124,103,064"
			},
			{
				"label": "Twitch",
				"value": 2560343616,
				"color": "#76349f",
				"caption": "Hours Watched: 2,560,343,616"
			},
			{
				"label": "Mixer",
				"value": 107544939,
				"color": "#0c86d4",
				"caption": "Hours Watched: 107,544,939"
				
			}
		]
	},
	"labels": {
		"outer": {
			"pieDistance": 38
		},
		"inner": {
			"hideWhenLessThanPercentage": 3
		},
		"mainLabel": {
			"font": "times new roman",
			"fontSize": 14
		},
		"percentage": {
			"color": "#ffffff",
			"font": "times new roman",
			"fontSize": 12,
			"decimalPlaces": 0
		},
		"value": {
			"color": "#adadad",
			"font": "times new roman",
			"fontSize": 14
		},
		"lines": {
			"enabled": true
		},
		"truncation": {
			"enabled": true
		}
	},
	"effects": {
		"pullOutSegmentOnClick": {
			"speed": 400,
			"size": 8
		}
	},
	"misc": {
		"gradient": {
			"enabled": true,
			"percentage": 100
		},
		"pieCenterOffset": {
			"x": 50
		}
	},
	"callbacks": {}
});